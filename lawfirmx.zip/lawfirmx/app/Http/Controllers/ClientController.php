<?php

namespace App\Http\Controllers;

use App\Mail\ClientRegistrationWelcomeEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class ClientController extends Controller
{

    public function adminDashboard()
    {
        $totalClients = DB::table('clients')->get()->count();
        $totalClientsWithNoPics = DB::table('clients')->where('profile_picture', NULL)->get()->count();
        $currentDate = date('Y-m-d');
        $primaryLegalCounsels = DB::table('primary_legal_counsels')->get();
        return view('admin.index', compact('currentDate', 'primaryLegalCounsels', 'totalClients', 'totalClientsWithNoPics'));
    }

    public function storeClients(Request $request)
    {
        $validateData = $request->validate([
            'email' => 'required|unique:clients|max:191',

        ]);

        $data = array();
        $data['first_name'] = $request->first_name;
        $data['last_name'] = $request->last_name;
        $data['email'] = $request->email;
        $data['case_details'] = $request->case_details;
        $data['date_of_birth'] = $request->date_of_birth;
        $data['primary_legal_counsel_id'] = $request->primary_legal_counsel_id;
        $data['created_at'] = date('Y-m-d');
        $image = $request->file('profile_picture');
        if ($image) {
            $image_name = date('dmy_H_s_i');
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name . '.' . $ext;
            $upload_path = 'backend/media/profilePic/';
            $image_url = $upload_path . $image_full_name;
            $success = $image->move($upload_path, $image_full_name);

            $data['profile_picture'] = $image_url;
            $client = DB::table('clients')->insert($data);
            Mail::to($data['email'])->send(new ClientRegistrationWelcomeEmail());
            return Redirect()->back()->with('message', 'Client Registered Successfully');
        } else {
            $client = DB::table('clients')->insert($data);
            Mail::to($data['email'])->send(new ClientRegistrationWelcomeEmail());
            return Redirect()->back()->with('message', 'Client Registered Successfully');
        }
    }

    public function allClients()
    {
        $allClients = DB::table('clients')->get();
        return view('admin.allClients', compact('allClients'));
    }

    public function clientProfile($id)
    {
        $clientProfile = DB::table('clients')->where('id', $id)->first();
        return view('admin.clientProfile', compact('clientProfile'));
    }
}

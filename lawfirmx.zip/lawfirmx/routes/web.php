<?php

use App\Http\Controllers\ClientController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', [ClientController::class, 'index']);
Route::get('/', [ClientController::class, 'adminDashboard'])->name('adminDashboard');
Route::post('/admin/store-clients', [ClientController::class, 'storeClients'])->name('storeClients');
Route::get('/admin/all-clients', [ClientController::class, 'allClients'])->name('allClients');
Route::get('/admin/client-profile/{id}', [ClientController::class, 'clientProfile']);
